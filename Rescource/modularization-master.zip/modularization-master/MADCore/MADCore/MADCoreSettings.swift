//
//  MADCoreSettings.swift
//  MADCore
//
//  Created by 梁宪松 on 2018/11/2.
//  Copyright © 2018 md. All rights reserved.
//

import UIKit

public class MADCoreSettings: NSObject {

    public static let SECRET_KEY = "SECRET_KEY"
}
