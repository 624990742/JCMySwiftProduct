//
//  MADCore.h
//  MADCore
//
//  Created by 梁宪松 on 2018/11/2.
//  Copyright © 2018 md. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MADCore.
FOUNDATION_EXPORT double MADCoreVersionNumber;

//! Project version string for MADCore.
FOUNDATION_EXPORT const unsigned char MADCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MADCore/PublicHeader.h>


