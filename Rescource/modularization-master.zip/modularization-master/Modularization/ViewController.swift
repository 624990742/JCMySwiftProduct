//
//  ViewController.swift
//  Modularization
//
//  Created by 梁宪松 on 2018/11/2.
//  Copyright © 2018 md. All rights reserved.
//

import UIKit
import MADCore

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // 调用 MADCore库文件
        let key = MADCoreSettings.SECRET_KEY
    }
}

