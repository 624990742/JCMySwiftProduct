# modularization
a demo for the practice of modularization

最近公司新开了个项目，需要从零开始搭建，之前做过一些组件化的工作，但是之前的开发语言是OC，新项目切换到了Swift，虽然差异不大，但是还是写了本文作为记录

tips: 这篇文章写得不错 [iOS swift的xcworkspace多项目管理（架构思想）](https://www.bbsmax.com/A/pRdBBwZ2dn/)

正如文章中所说，多工程需要面临的几个问题
*   各个工程如何创建，如何维护第三方的依赖（这里使用Cocopods进行依赖管理）
*   主工程如何调用Library工程
*   Library之前的依赖和调用

跟着我走一遍流程，follow me， Let's start it!
.......略略略......

篇幅所限，请移架简书 [简书地址](https://www.jianshu.com/p/ae581ea8a011)
