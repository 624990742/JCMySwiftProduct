//
//  MADBase.h
//  MADBase
//
//  Created by 梁宪松 on 2018/11/2.
//  Copyright © 2018 md. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MADBase.
FOUNDATION_EXPORT double MADBaseVersionNumber;

//! Project version string for MADBase.
FOUNDATION_EXPORT const unsigned char MADBaseVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MADBase/PublicHeader.h>


