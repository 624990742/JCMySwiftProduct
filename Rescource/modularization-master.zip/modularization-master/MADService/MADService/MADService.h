//
//  MADService.h
//  MADService
//
//  Created by 梁宪松 on 2018/11/2.
//  Copyright © 2018 md. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MADService.
FOUNDATION_EXPORT double MADServiceVersionNumber;

//! Project version string for MADService.
FOUNDATION_EXPORT const unsigned char MADServiceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MADService/PublicHeader.h>


